#ifndef __ASM_ARM_MEMORY_H
#define __ASM_ARM_MEMORY_H

#endif	/* __ASM_ARM_MEMORY_H */
