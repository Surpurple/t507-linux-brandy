#ifndef HEADER_MYFUNTION_H
#define HEADER_MYFUNTION_H

#include <common.h>

#endif
