// Copyright 2010 Google Inc. All Rights Reserved.
// Use of this source code is governed by an Apache-style license that can be
// found in the COPYING file.
//
// Macros specific to the RLZ library.

#ifndef RLZ_WIN_LIB_ASSERT_H_
#define RLZ_WIN_LIB_ASSERT_H_



#endif  // RLZ_WIN_LIB_ASSERT_H_
