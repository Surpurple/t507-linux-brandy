#define CI_INFO "014c43e7"
